<?php
class Azure_app_service_migration_Import_AjaxHandler {
    public function handle_ajax_requests_admin() {
    }
}
?>
